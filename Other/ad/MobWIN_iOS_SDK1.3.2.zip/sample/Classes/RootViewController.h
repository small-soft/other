//
//  RootViewController.h
//  MobWinSample
//
//  Created by Guo Zhao on 11-12-26.
//  Copyright 2011 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
	NSArray *ads_iPhone;
	NSArray *ads_iPad;
}

@end
