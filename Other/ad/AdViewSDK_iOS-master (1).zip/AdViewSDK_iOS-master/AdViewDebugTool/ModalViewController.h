//
//  ModalViewController.h
//  AdViewSDK_Sample
//
//  Copyright 2010 www.adview.cn All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ModalViewController : UIViewController {

}

- (IBAction)dismiss:(id)sender;

@end
