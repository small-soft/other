//
//  BottomBannerController.h
//  AdViewSDK_Sample
//
//  Copyright 2010 www.adview.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SimpleViewController.h"

@interface BottomBannerController : SimpleViewController {

}

@end
