//
//  main.m
//  AdViewDebugTool
//
//  Created by Wang Yunshan on 11-11-25.
//  Copyright 2011年 www.adview.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
