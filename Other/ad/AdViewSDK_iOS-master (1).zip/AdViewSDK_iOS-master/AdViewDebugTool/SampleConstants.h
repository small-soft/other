/*

 SampleConstants.h
 
 Copyright 2010 www.adview.cn

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 
*/

//#define kSampleAppKey @"SDK20121616040605215hfjoroof0ql8"		//@死神的左手
//#define kSampleAppKey @"SDK2012202108055350s2lp06ru215tw"

//#define kSampleAppKey @"SDK20121002100543cqsnmqsrbozod81"		//adview.

//#define kSampleAppKey @"SDK201117041405591begftk60epsig5"

#define kSampleAppKey @"SDK20111022530129m85is43b70r4iyc"
//#define kSampleAppKey @"SDK20112008511035ylhncq1qd1r4oq5"

//#define kSampleAppKey @"SDK20111808491246d5nwkucn9f80jfo"
//#define kSampleAppKey @"SDK20111004301104sk55wewpb31i8bv"
//#define kSampleAppKey @"SDK2011102043122233hsbixt2eng4z7"

//#define kSampleAppKey @"SDK2012171320035622ft8z08vllslpj"