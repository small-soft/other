/*
 
 Copyright 2010 www.adview.cn. All rights reserved.
 
 */

#import "AdViewAdNetworkAdapter+helpers.h"
#import "DMAdView.h"


@interface AdViewAdapterDoMob : AdViewAdNetworkAdapter {

}

+ (AdViewAdNetworkType)networkType;

@end
