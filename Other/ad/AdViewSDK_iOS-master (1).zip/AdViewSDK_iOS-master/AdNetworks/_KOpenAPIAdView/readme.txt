for KAdView & SuiZong

OpenAPI means the server api is opened to adview by ad platform(like suizong).