/*
 
 Copyright 2010 www.adview.cn. All rights reserved.
 
 */

#import <immobSDK/immobView.h>
#import "AdViewAdNetworkAdapter.h"

@interface AdViewAdapterImmob: AdViewAdNetworkAdapter<immobViewDelegate> {
}

@end
