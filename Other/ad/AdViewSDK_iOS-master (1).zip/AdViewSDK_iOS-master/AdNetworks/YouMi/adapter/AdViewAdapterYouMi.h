/*
 
 Copyright 2010 www.adview.cn. All rights reserved.
 
 */

#import "AdViewAdNetworkAdapter.h"
#import "YouMiDelegateProtocol.h"

@class YouMiView;

@interface AdViewAdapterYouMi : AdViewAdNetworkAdapter {
}

+ (AdViewAdNetworkType)networkType;

@end
