//
//  SinaAccountGetUID.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 10/23/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

//对应sina的v2版本API account/get_uid 
//OAuth授权之后，获取授权用户的UID

#import "../MSSinaWeiboPackage.h"

@interface MSSinaAccountGetUID : MSSinaWeiboPackage
{
    
}
@end
