//
//  SinaFriendshipsFriends.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/12/11.
//  Copyright (c) 2011 www.adview.cn. All rights reserved.
//

//对应sina的v2版本API friendships/friends
//获取用户的关注列表

#import "../MSSinaWeiboPackage.h"

@interface MSSinaFriendshipsFriends : MSSinaWeiboPackage
{
    
}
@end
