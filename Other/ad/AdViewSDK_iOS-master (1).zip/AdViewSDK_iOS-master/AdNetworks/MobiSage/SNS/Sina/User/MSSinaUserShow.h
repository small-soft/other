//
//  SinaUserShow.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 10/23/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

//对应sina的v2版本API users/show
//根据用户ID获取用户信息

#import "../MSSinaWeiboPackage.h"

@interface MSSinaUserShow : MSSinaWeiboPackage
{
    
}
@end
