//
//  SinaStatusUpdate.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 10/23/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

//对应sina的v2版本API statuses/update
//发布一条新微博


#import "../MSSinaWeiboPackage.h"

@interface MSSinaStatusUpdate : MSSinaWeiboPackage
{
    
}
@end
