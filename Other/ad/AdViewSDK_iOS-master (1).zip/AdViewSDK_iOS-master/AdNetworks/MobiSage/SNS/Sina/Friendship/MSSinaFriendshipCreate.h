//
//  SinaFriendshipCreate.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/3/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

//对应sina的v2版本API friendships/create
//关注一个用户

#import "../MSSinaWeiboPackage.h"

@interface MSSinaFriendshipCreate : MSSinaWeiboPackage
{
    
}
@end
