//
//  OAConsumer.h
//  OAuthHelper
//
//  Created by Ryou Zhang on 12/2/10.
//  Copyright 2010 appSage. All rights reserved.
//

@interface MSOAConsumer : NSObject
{
}
@property(retain)NSString* key, *secret;
@end
