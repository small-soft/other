//
//  TencentFriendsAdd.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/9/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

#import "../MSTencentWeiboPackage.h"

@interface MSTencentFriendsAdd : MSTencentWeiboPackage
{
    
}
@end
