//
//  RenrenFriendsGetFriends.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/11/11.
//  Copyright (c) 2011 www.adview.cn. All rights reserved.
//

#import "../MSRenrenPackage.h"

@interface MSRenrenFriendsGetFriends : MSRenrenPackage
{
    
}
@end
