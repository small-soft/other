//
//  RenrenPagesBecomeFan.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/14/11.
//  Copyright (c) 2011 www.adview.cn. All rights reserved.
//

#import "../MSRenrenPackage.h"

@interface MSRenrenPagesBecomeFan : MSRenrenPackage
{
    
}
@end
