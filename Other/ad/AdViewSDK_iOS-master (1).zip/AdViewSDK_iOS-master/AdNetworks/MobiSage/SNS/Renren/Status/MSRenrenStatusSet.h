//
//  RenrenStatusSet.h
//  MobiSageSDK
//
//  Created by Ryou Zhang on 11/9/11.
//  Copyright (c) 2011 mobiSage. All rights reserved.
//

#import "../MSRenrenPackage.h"

@interface MSRenrenStatusSet : MSRenrenPackage
{
    
}
@end
