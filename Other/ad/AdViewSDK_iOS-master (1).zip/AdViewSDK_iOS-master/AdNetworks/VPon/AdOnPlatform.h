//
//  AdOnPlatform.h
//  iphone-sdk2
//
//  Created by Shark on 2010/10/14.
//  Copyright 2010 www.adview.cn. All rights reserved.
//

typedef enum {
	CN, TW
} Platform;
